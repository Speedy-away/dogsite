Scooby Overwatch PS4 v1.0.0

Target: CUSA03974. Beta: full console acceptance is not implied.

Close the game before installation. Copy GoldHEN and Scooby folders into /data.
Merge the included plugins.ini entry into /data/GoldHEN/plugins.ini; do not replace other entries.
The plugin destination is /data/GoldHEN/plugins/ScoobyOverwatch.sprx.
Copy the user folder into the PS4 filesystem root / using FTP for the Scooby notification logo.
Preserve existing account.json and configs. account.example.json is blank; rename/edit it only if needed.
RDR2 Premium requires valid credentials and an active subscription. Adding account.json requires a game restart.
Other game projects remain Free. Free switch:0 enabled,1 disabled; verified Premium is independent.
Restart the game after installation. Never share completed account.json or device.id.
