<p align="center">
  <img src="https://readme-typing-svg.vercel.app/?lines=Ultimate+Menu+Script;Most+Useful+Script&font=Fira%20Code&size=31&center=true&width=380&height=50&duration=4000&pause=1000" alt="Typing Banner">
</p>

<h1 align="center">Ultimate Menu</h1>

<p align="center"><em>A powerful menu script featuring advanced recovery options, money tools, a Heist Editor, and much more.</em></p>

<p align="center">
  <a href="https://www.unknowncheats.me/forum/grand-theft-auto-v/565688-ultimate-menu-script.html">[ModestMenu UKC Thread]</a> • 
  <a href="https://www.unknowncheats.me/forum/grand-theft-auto-v/597103-ultimate-menu-yimmenu.html">[YimMenu UKC Thread]</a> • 
  <a href="https://github.com/UltimateMenu/UltimateMenu?tab=readme-ov-file#-faq">[FAQ]</a>
</p>

> [!NOTE]  
> [How To Use YimMenu After BattlEye Anticheat Update (Legacy & Enhanced)](https://github.com/UltimateMenu/UltimateMenu/wiki/How-To-Use-UM-Script-With-YimMenu-After-Battleye-Anticheat-(Legacy-&-Enhanced))

---

<h2 align="center">📸 YimMenu Preview (Legacy)</h2>

<p align="center">
  <img src="https://ultimatemenu.github.io/ScreenShots/YimMenu/15.png" alt="Ultimate Menu Preview">
</p>

---

## ❓ FAQ

<details>
  <summary><strong>How To Use?</strong></summary>

- For **YimMenu Legacy**:  
  Open YimMenu → `Settings` → `Lua` → `Open Folder` → `scripts`  
  → Paste the `.lua` file there. That’s it!
  
- For **YimMenuV2 Enhanced**:  
  Coming Soon (WIP)
</details>

---

## 📅 Update Info

- **Ultimate Menu for ModestMenu**: Last updated on **Dec 12, 2024** *(Final Update)*  
- **Ultimate Menu for YimMenu Legacy**: Last updated on **Jul 24, 2026**
- **Ultimate Menu for YimMenu Enhanced**: **Might Not Coming Soon (WIP Waiting for completion of YimMenuV2 Lua API)**

---

## 🛠️ About

This is a fun and helpful free project for the community.  
There is **no ETA** for future big updates, as I’m currently focused on studying and personal life.

You're welcome to fork, use, and build on this script for your own needs.  
Treat it as a base or template if you wish.

Credits For Everything I Used Is Included In The Script.

---

<h2 align="left">💬 Discord Server</h2>

<p align="left">
  <a href="https://dsc.gg/l7neg">
    <img src="https://discord.com/api/guilds/1025804814183047218/widget.png?style=banner2" alt="L7NEG Community Discord Server">
  </a>
</p>

---

**Thanks for using Ultimate Menu Made With ❤️ By L7NEG & Contributors/Helpers**
