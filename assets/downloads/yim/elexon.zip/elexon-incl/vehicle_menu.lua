return function(parent)
    if not parent then
        log.error("Vehicle menu parent menu is nil")
        return
    end

local removed_vehicles = require("elexon-incl.removed_vehicles")                            -- load the removed vehicles list
-------------------------------------------------------------------------------------------------------------
--[[ Claim Vehicle as PV function ]]--
-------------------------------------------------------------------------------------------------------------
local GARAGE_MENU_DATA    = 176 -- 3A ? 42 ? 71 3A ? 42 ? 71 3A ? 42 ? 71 3A ? 42 ? 71 3A ? 42 ? 71 71 +1
local VEHICLE_REWARD_DATA = 129 -- 3A ? 40 ? 5D ? ? ? 2A +1

local should_run_script = false

--[[ Claim Current Vehicle as Personal Vehicle(PV) ]]
-- will move to vehicle_menu.lua later

local function IS_VEHICLE_VALID_FOR_PV(vehicle_hash)
    return scr_function.call_script_function("freemode", 0x913BB, "bool", {
        { "int", vehicle_hash }
    })
end

local function GIVE_VEHICLE_REWARD(vehicle_id, data, transaction, garage, slot, state)
    return scr_function.call_script_function("am_mp_vehicle_reward", "GVR", "2D 0C 1E 00 00", "bool", {
        { "int", vehicle_id },
        { "ptr", data },
        { "ptr", transaction },
        { "ptr", garage },
        { "ptr", slot },
        { "ptr", state },
        { "bool", false }, -- ???
        { "bool", true },  -- Set as Last PV
        { "bool", true },  -- Display Cancel Error Message
        { "bool", false }, -- Is Podium Vehicle
        { "int", 0 },      -- ???
        { "int", -1 }      -- ???
    })
end

local function RUN_SCRIPT()
    if not ENTITY.DOES_ENTITY_EXIST(self.get_veh()) then
        should_run_script = false
        return
    end

    local menu_data          = locals.get_pointer("am_mp_vehicle_reward", GARAGE_MENU_DATA)
    local transaction_result = locals.get_pointer("am_mp_vehicle_reward", VEHICLE_REWARD_DATA + 4)
    local garage_id          = locals.get_pointer("am_mp_vehicle_reward", VEHICLE_REWARD_DATA + 5)
    local garage_slot        = locals.get_pointer("am_mp_vehicle_reward", VEHICLE_REWARD_DATA + 6)
    local reward_state       = locals.get_pointer("am_mp_vehicle_reward", VEHICLE_REWARD_DATA + 7)
	
    if GIVE_VEHICLE_REWARD(self.get_veh(), menu_data, transaction_result, garage_id, garage_slot, reward_state) then
        if locals.get_int("am_mp_vehicle_reward", VEHICLE_REWARD_DATA + 7) ~= 3 then
            locals.set_int("am_mp_vehicle_reward", VEHICLE_REWARD_DATA + 4, 0)
            locals.set_int("am_mp_vehicle_reward", VEHICLE_REWARD_DATA + 5, 0)
            locals.set_int("am_mp_vehicle_reward", VEHICLE_REWARD_DATA + 6, 0)
            locals.set_int("am_mp_vehicle_reward", VEHICLE_REWARD_DATA + 7, 0)
            should_run_script = false
        end
    end
end

script.register_looped("Vehicle Reward", function()
    if not script.is_active("am_mp_vehicle_reward") then
        should_run_script = false
        return
    end

    if should_run_script then
        RUN_SCRIPT()
    end
end)

parent:add_text("Vehicle Menu Options")
parent:add_button("Claim current Vehicle as PV", function()
    script.run_in_fiber(function()
        if network.is_session_started() and script.is_active("freemode") and script.is_active("am_mp_vehicle_reward") then
            if PED.IS_PED_IN_ANY_VEHICLE(self.get_ped(), false) then
                if IS_VEHICLE_VALID_FOR_PV(ENTITY.GET_ENTITY_MODEL(self.get_veh())) then
                    should_run_script = true
                else
                    log.debug("Vehicle Reward", "This vehicle cannot be saved as a personal vehicle.")
                end
            else
                log.debug("Vehicle Reward", "Please get in a vehicle.")
            end
        else
            log.debug("Vehicle Reward", "Cannot give vehicle at the moment. Are you online?")
        end
    end)
end)


--------------------------------------------------------------------------------------------------------------
--[[ Auto load removed vehicles on session start ]]--
--------------------------------------------------------------------------------------------------------------

local removed_vehicles_triggered = false

script.register_looped("removed_vehicles_auto", function(script)
    script:yield()
    if network.is_session_started() and not removed_vehicles_triggered then
        log.debug("[Load Removed Vehicles][DEBUG] Starting auto-trigger for removed vehicles")
        for _, offset in ipairs(removed_vehicles) do -- iterate through each offset
            print("[Load Removed Vehicles][DEBUG] Setting global: " .. tostring(262145 + offset))
            globals.set_int(262145 + offset, 1) -- set the global to 1
        end
        log.debug("[Load Removed Vehicles][DEBUG] Finished auto-trigger")
        removed_vehicles_triggered = true
    end
end)

end