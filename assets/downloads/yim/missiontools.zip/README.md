# Mission Tools

A versatile YimMenu script featuring mission selectors, skip tools, cooldown management, session switching, and much more.

## Features

- 5 mission selectors (ULP, DOSE, KnoWay Out, Lamar/Lowrider, Yacht) with live auto-update (more missions support soon)
- One-click skips with undo for all supported mission chains
- Cooldown removal for Dax calls and VIP/MC timers
- Session switcher with 9 types + Leave GTA Online

## Tabs

| Tab | What's in it |
|---|---|
| Missions Manager | Dropdowns, session switcher, save/load |
| Mission Skips | Skip and undo buttons for each mission line |
| Cooldown Utilities | CD removal and undo |

## Install

1. Grab `MissionTools.lua` from [releases](../../releases)
2. Drop it in `%APPDATA%/YimMenu/scripts/`
3. Reload scripts in YimMenu
4. Open the Mission Tools tab

## Heads up

- Save/load state is temp right now. It lives in memory and dies when you reload the script or close YimMenu. Persistent saves are coming later.
- Session switching uses freemode.c globals. If Rockstar pushes an update, these offsets might shift and need updating.
- KnoWay Out and Lamar missions changes won't stick until you switch sessions.
- Dropdowns pick up in-game mission progress automatically, no refresh needed.

## Contributing

Found a bug? Open an issue with:
- What you did
- What happened
- What should have happened
- Your YimMenu version and GTA build number

Want to add something? PRs are welcome. Please keep the same style as the existing code and test before submitting.

## Planned

- Persistent file-based saves
- More missions (soon)

## License

MIT
