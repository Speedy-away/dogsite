Thank you for downloading Dababy Car
This mod uses Modkit id: 0

Description:
Dababy Car


Features:
Dababy head on wheels.

Installation: (OpenIV is needed)      OpenIV Link: http://openiv.com/

1. Start OpenIV 
2. Grand Theft Auto V\mods\update\x64\dlcpacks
3. Drop the folder named "stew_car" here.
4. Then go to Grand Theft Auto V\mods\update\update.rpf\common\data and add "<Item>dlcpacks:\stew_car\</Item>" to the dlclist.xml
(make sure to activate edit mode otherwise you won't be able to edit the code)

Also Required:
1. https://www.gta5-mods.com/misc/gta-5-gameconfig-300-cars
2. https://www.gta5-mods.com/scripts/heapadjuster

Spawn the Dababy Car via a mod menu with this spawn name: "car"

This mod is NOT an accurate representation of my work, it took 0 time. XD 