# Scooby Studio

Load `ScoobyStudio.lua` in Scooby's Lua manager with the `ScoobyStudio/` directory alongside it. Requires GUI API 2026.10.1; LuaJIT is already included in Scooby. In-game acceptance on each GTA build remains required.

F6 opens/closes the workspace; F7 toggles the speedometer; F8 toggles keybinds. An XInput controller can use LB + RB + X. Mouse interaction is handled by the standalone window. Gameplay controls are suppressed while it is open; it opens immediately after loading.

Features: health/armour/clean/wanted tools; vehicle repair, wash, upright, engine, doors, automatic repair, primary/secondary RGB paint and plate; three saved locations and map waypoint travel; eight weather presets and time controls; speedometer with KM/H or MPH, coordinates, crosshair, local-player health/armour, keybinds and status badge. Filter controls with the search box. Settings save display preferences and location slots. Gameplay toggles start off.

Vehicle edits require the current driver seat. Buttons queue work to a script fiber and resolve current handles when executed. The script removes callbacks, stops per-frame effects and releases its own weather override on unload. One-shot health, vehicle, location and clock edits persist as normal game actions.

The screenshot-inspired layout uses charcoal panels and violet accents. Feature concepts were compared with Jackz Vehicles (https://github.com/Jackzmc/stand-lua-scripts), the speedometer/teleport collections in https://github.com/0x2XPx/2Take1-script-Archive, and the local Cherax PaintLabs/Vehicle Forge references. This package is an original Scooby implementation; those menus' scripts are not imported or auto-run.

`model.lua` owns UI state/action queues; `host.lua` contains game access; `ui.lua` renders the interface. Extend a feature through the queue and keep native work out of render callbacks.
