local ui=compat.yim.ImGui
local U={}
local C={bg={0.060,0.063,0.078,1},panel={0.085,0.090,0.110,1},raised={0.115,0.122,0.150,1},text={0.86,0.88,0.94,1},muted={0.56,0.60,0.69,1},accent={0.59,0.51,1,1}}
local function color(name,v) ui.PushStyleColor(ImGuiCol[name],unpack(v)) end
local function theme()
    local colors={WindowBg=C.bg,ChildBg=C.panel,PopupBg=C.raised,Text=C.text,TextDisabled=C.muted,Border={0.16,0.17,0.21,1},FrameBg=C.raised,
        FrameBgHovered={0.18,0.18,0.24,1},FrameBgActive={0.24,0.22,0.36,1},Button=C.raised,ButtonHovered={0.25,0.22,0.39,1},ButtonActive={0.34,0.28,0.53,1},
        Header={0.22,0.19,0.34,1},HeaderHovered={0.27,0.23,0.42,1},HeaderActive={0.34,0.28,0.53,1},CheckMark=C.accent,SliderGrab=C.accent,SliderGrabActive=C.accent,
        ScrollbarBg=C.bg,ScrollbarGrab={0.29,0.26,0.45,1},ScrollbarGrabHovered=C.accent,ScrollbarGrabActive=C.accent,Separator={0.17,0.18,0.22,1},PlotHistogram=C.accent}
    local count=0;for k,v in pairs(colors) do color(k,v);count=count+1 end
    ui.PushStyleVar(ImGuiStyleVar.WindowRounding,10);ui.PushStyleVar(ImGuiStyleVar.ChildRounding,7)
    ui.PushStyleVar(ImGuiStyleVar.FrameRounding,4);ui.PushStyleVar(ImGuiStyleVar.WindowPadding,16,16)
    ui.PushStyleVar(ImGuiStyleVar.FramePadding,9,7);ui.PushStyleVar(ImGuiStyleVar.ItemSpacing,10,10)
    return count
end
local function heading(text) ui.Text(text);ui.Separator();ui.Spacing() end
local function toggle(s,label,key)
    if s.search~="" and not label:lower():find(s.search:lower(),1,true) then return end
    s.options[key]=ui.Checkbox(label,s.options[key])
end
local function button(s,label,action,width)
    if s.search~="" and not label:lower():find(s.search:lower(),1,true) then return end
    if ui.Button(label,width or -1,30) then s:enqueue(action) end
end
local function card(name,w,h,fn)
    ui.BeginChild(name,w,h,false);heading(name);fn();ui.EndChild()
end
local function controls(s,w)
    local col=(w-10)/2
    if s.page=="Overlay" then
        card("ON-SCREEN PANELS",col,310,function()
            toggle(s,"Status badge","watermark");toggle(s,"Keybind list","keybinds");toggle(s,"Player status","status")
            toggle(s,"Vehicle speedometer","speedometer");toggle(s,"Coordinates","coordinates");toggle(s,"Center crosshair","crosshair")
        end);ui.SameLine()
        card("DISPLAY",col,310,function()
            toggle(s,"Speed in MPH","mph");toggle(s,"Hide game HUD","hide_hud")
            ui.Spacing();ui.TextWrapped("Panels stay visible when this window is closed. F6 brings you back.")
            ui.Spacing();button(s,"Reset panel positions","reset_layout")
        end)
    elseif s.page=="Self" then
        card("PLAYER TOOLS",col,310,function()
            button(s,"Restore health","heal");button(s,"Fill armour","armour");button(s,"Clear wanted level","wanted");button(s,"Clean player","clean")
        end);ui.SameLine()
        card("LOCAL PLAYER",col,310,function()
            local p=s.snapshot;ui.Text(p.name or "Local player");ui.Spacing()
            ui.ProgressBar(math.max(0,p.health)/math.max(1,p.max_health),-1,8,"")
            ui.Text(string.format("Health  %d / %d",p.health,p.max_health));ui.Text("Armour  "..p.armour)
            ui.Spacing();toggle(s,"Player status panel","status");toggle(s,"Coordinates panel","coordinates")
        end)
    elseif s.page=="Vehicle" then
        card("WORKSHOP",col,390,function()
            button(s,"Repair vehicle","car_repair");button(s,"Wash vehicle","car_wash");button(s,"Upright vehicle","car_flip")
            button(s,"Start engine","car_engine_on");button(s,"Stop engine","car_engine_off")
            button(s,"Open doors","car_doors_open");button(s,"Close doors","car_doors_close");toggle(s,"Auto repair (driver)","auto_repair")
        end);ui.SameLine()
        card("PAINT & PLATE",col,390,function()
            s.paint=ui.ColorEdit3("Paint",s.paint);button(s,"Apply to both colors","car_paint")
            ui.Spacing();s.plate=ui.InputText("Plate",s.plate,9);button(s,"Apply plate","car_plate")
            ui.Spacing();toggle(s,"Speedometer","speedometer");toggle(s,"Use MPH","mph")
            ui.TextWrapped("Vehicle actions use your current driver seat.")
        end)
    elseif s.page=="World" then
        card("WEATHER",col,310,function()
            s.weather=ui.Combo("Preset",s.weather,{"Extra sunny","Clear","Clouds","Overcast","Rain","Thunder","Fog","Light snow"},8)
            button(s,"Apply weather","weather");button(s,"Release weather override","weather_reset")
        end);ui.SameLine()
        card("TIME OF DAY",col,310,function()
            s.hour=ui.SliderInt("Hour",s.hour,0,23);button(s,"Set time","clock")
            if ui.Button("Noon",-1,30) then s.hour=12;s:enqueue("clock") end
            if ui.Button("Midnight",-1,30) then s.hour=0;s:enqueue("clock") end
        end)
    elseif s.page=="Teleport" then
        card("SAVED LOCATIONS",col,310,function()
            s.slot=ui.Combo("Slot",s.slot,{"Location 1","Location 2","Location 3"},3)
            button(s,"Save current location","bookmark_save");button(s,"Return to location","bookmark_return")
            local p=s.bookmarks[tostring(s.slot)]
            if p then ui.TextWrapped(string.format("%.1f, %.1f, %.1f",p.x,p.y,p.z)) else ui.TextDisabled("No location saved") end
        end);ui.SameLine()
        card("TRAVEL",col,310,function()
            button(s,"Go to map waypoint","waypoint");ui.TextWrapped("Set a waypoint on the map. Vehicles travel with you when you are the driver.")
            ui.Spacing();button(s,"Save locations to config","save_preferences")
        end)
    else
        card("CONTROLS",col,310,function()
            toggle(s,"Controller menu shortcut","controller")
            ui.TextWrapped("F6: menu\nF7: speedometer\nF8: keybind list\nLB + RB + X: menu")
            ui.Spacing();button(s,"Save preferences","save_preferences");button(s,"Reset layout","reset_layout")
        end);ui.SameLine()
        card("LUA STUDIO",col,310,function()
            ui.Text("Scooby Studio 1.0");ui.TextDisabled("LuaJIT / Yim-style GUI")
            ui.Spacing();ui.TextWrapped("Self, vehicle, world and overlay tools. Module-based and ready to extend.")
            ui.Spacing();ui.TextWrapped("Load ScoobyStudio.lua together with its ScoobyStudio folder.")
        end)
    end
end
local function panel(name,x,y,w,h,fn,reset,interactive)
    ui.SetNextWindowPos(x,y,reset and ImGuiCond.Always or ImGuiCond.FirstUseEver)
    ui.SetNextWindowSize(w,h,ImGuiCond.Always)
    local flags=ImGuiWindowFlags.NoTitleBar+ImGuiWindowFlags.NoResize+ImGuiWindowFlags.NoCollapse+ImGuiWindowFlags.NoSavedSettings
    if not interactive then flags=flags+ImGuiWindowFlags.NoInputs end
    local visible=ui.Begin(name,flags)
    if visible then fn() end
    ui.End()
end
function U.draw(s)
    local nc=theme();local dw,dh=ui.GetDisplaySize();local reset=s.reset_layout
    local mainw=math.min(860,math.max(640,dw-80));local mainh=math.min(590,dh-70)
    local x=math.max(24,(dw-mainw-280)/2);local y=math.max(32,(dh-mainh)/2)
    if input.is_key_pressed(input.keys.F6) then s.open=not s.open end
    if not ui.IsAnyItemActive() then
        if input.is_key_pressed(input.keys.F7) then s.options.speedometer=not s.options.speedometer end
        if input.is_key_pressed(input.keys.F8) then s.options.keybinds=not s.options.keybinds end
    end
    if s.options.controller and input.is_gamepad_connected and input.is_gamepad_connected() then
        -- XInput masks; the host snapshots one edge per render frame.
        if input.is_gamepad_button_down(0x100) and input.is_gamepad_button_down(0x200) and input.is_gamepad_button_pressed(0x4000) then s.open=not s.open end
    end
    if s.open then
        panel("Scooby Studio##main",x,y,mainw,mainh,function()
            ui.BeginChild("sidebar",166,-1,false)
            ui.Text("SCOOBY STUDIO");ui.TextDisabled("GTA V  /  Lua workspace");ui.Spacing();ui.Separator();ui.Spacing()
            for _,group in ipairs({{"VISUALS","Overlay","World"},{"MISC","Self","Vehicle","Teleport"},{"OTHER","Settings"}}) do
                ui.TextDisabled(group[1])
                for i=2,#group do if ui.Selectable(group[i],s.page==group[i],0,0,32) then s.page=group[i];s.search="" end end
                ui.Spacing()
            end
            ui.EndChild();ui.SameLine();ui.BeginChild("content",0,-1,false)
            ui.Text("WORKSPACE  /  "..s.page:upper());ui.SameLine()
            if ui.SmallButton("Close [F6]") then s.open=false end
            ui.Spacing();ui.SetNextItemWidth(-1);s.search=ui.InputTextWithHint("##search","Filter controls...",s.search,128)
            ui.Spacing();local available=ui.GetContentRegionAvail();controls(s,available)
            ui.Spacing();ui.Separator();ui.TextWrapped((s.error and "!  " or ">  ")..s.message)
            ui.EndChild()
        end,reset,true)
    end
    local side_x=math.min(dw-280,x+mainw+16);local side_y=y+18
    local p=s.snapshot
    if s.options.watermark then
        panel("Studio badge",math.max(8,dw-445),18,425,48,function()
            ui.Text(string.format("SCOOBY  |  %s  |  %d players  |  %.0f FPS",p.online and "Online" or "Story",p.players,ui.GetFrameRate()))
        end,reset,false)
    end
    if s.options.keybinds and (not s.open or dw>mainw+320) then
        panel("Studio keybinds",side_x,side_y,260,172,function()
            heading("KEYBINDS");ui.Text("Menu                       F6");ui.Text("Speedometer                F7");ui.Text("Keybind list               F8")
            if s.options.controller then ui.TextDisabled("Controller  LB + RB + X") end
        end,reset,false)
        side_y=side_y+184
    end
    if s.options.status and (not s.open or dw>mainw+320) then
        panel("Studio player status",side_x,side_y,260,135,function()
            ui.Text(p.name or "Local player");ui.TextDisabled(p.available and "LOCAL PLAYER" or "WAITING FOR PLAYER")
            ui.ProgressBar(math.max(0,p.health)/math.max(1,p.max_health),-1,7,"")
            ui.Text(string.format("HP %d / %d    Armour %d",p.health,p.max_health,p.armour))
        end,reset,false)
    end
    if s.options.speedometer then
        panel("Studio speedometer",math.max(8,dw-275),dh-110,255,86,function()
            local speed=math.max(0,p.speed)*(s.options.mph and 2.236936 or 3.6)
            ui.Text(string.format("%03.0f  %s",speed,s.options.mph and "MPH" or "KM/H"));ui.TextDisabled(p.vehicle~=0 and "VEHICLE TELEMETRY" or "ON FOOT")
        end,reset,false)
    end
    if s.options.coordinates then panel("Studio coordinates",20,dh-75,355,53,function() ui.Text(string.format("X %.1f   Y %.1f   Z %.1f",p.x,p.y,p.z)) end,reset,false) end
    if s.options.crosshair then
        panel("Studio crosshair",dw/2-16,dh/2-16,32,32,function()
            local px,py=ui.GetWindowPos();local draw=ui.GetWindowDrawList();local c=ui.ColorConvertFloat4ToU32(unpack(C.accent))
            draw:AddLine(px+8,py+16,px+24,py+16,c,2);draw:AddLine(px+16,py+8,px+16,py+24,c,2)
        end,true,false)
    end
    s.reset_layout=false;ui.PopStyleVar(6);ui.PopStyleColor(nc)
end
return U
